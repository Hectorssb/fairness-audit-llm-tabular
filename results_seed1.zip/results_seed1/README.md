# Results of the demonstration draw with seed 1

Outputs of the conditions that receive demonstrations (`D1_original`,
`D2_fair_causal`, `D3_resampled`, `D4b_D1`, `D4b_D2`, `D4r_D1`, `D4r_D2`,
`D5_decontam` and `D6_fairprompt`), with the ten demonstrations drawn with
`DEMO_SEED=1`: 384 passes on the test instances and prompts of `results/`.
The article refers to this draw as draw B, and to the one in `results/`
(seed 42) as draw A.

The layout and the file schema are those described in `results/README.md`.
Every filename carries `_seed1` before its suffix, for example
`adult_D1_original_LLM_FewShot_<model_tag>_seed1_predictions.csv`. The
conditions without demonstrations (`D4a`, `D4r_0`, `ZS_D1` and `ZS_D5`) do not
depend on the draw and are only in `results/`.
