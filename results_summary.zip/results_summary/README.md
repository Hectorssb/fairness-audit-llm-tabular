# Cell tables of the three demonstration draws

One row per cell (condition, model, dataset, protected attribute and test set;
1,104 cells), scored with `analysis/cells.py`:

- `cells_draw_A.csv`: `load_cells()`, from `results/` (seed 42).
- `cells_draw_B.csv` and `cells_draw_C.csv`: `load_cells(seed=1)` and
  `load_cells(seed=8)`, which read the conditions with demonstrations from
  `results_seed1/` and `results_seed8/` and the rest from `results/`.
- `cells_three_draws.csv`: the three draws taken together, as the last analysis
  section of `analysis.ipynb` builds it.

The conditions without demonstrations (`D4a`, `D4r_0`, `ZS_D1` and `ZS_D5`) do
not depend on the draw and carry the same rows in the three per-draw tables.

Columns of the per-draw tables:

- `test_set`: `T1` (files without a tag) or `T2` (files tagged `_testD2`).
- `EOD`, `DI`, `SPD`, `OD`: fairness metrics of the cell.
- `accuracy`: mean of the accuracy of the two groups. `baseline`: the
  majority-class predictor scored the same way.
- `N_*`, `TPR_*`, `FPR_*`, `PPP_*`: size and rates of the privileged and the
  unprivileged group.
- `collapsed`: collapse flag. `raw_gf`: EOD and DI both within range. `gf`:
  `raw_gf` and not collapsed. `gf_useful`: `gf` with an accuracy that reaches
  the baseline.

In `cells_three_draws.csv` every metric is the median of its three values,
`*_draws` counts the draws under which the state holds (0 to 3), and
`collapsed` and `gf` are the states that hold under at least two draws.
For DI, a finite summary requires at least two finite draws. Two finite ratios are averaged before display rounding. A majority of undefined ratios is reported as undefined. A majority of positive infinities is reported as positive infinity.
The notebook writes this table to `analysis/cells_three_draws.csv` under the
column names of the module (`cond`, `feature`, `acc`, and `test` as `D1` or
`D2`).

A count of the article is obtained from the per-draw tables: the state is
summed in each of them and the median of the three sums is reported. The
`collapsed` and `gf` columns of `cells_three_draws.csv` are the states shown in
the heatmaps, and their sum can differ from that median by up to 7 cells for a
condition and test set.

`demonstrations.csv` lists the ten demonstrations of every dataset, training
split and draw: `position` is the place of the example in the prompt, `row` its
zero-based row in `data/<dataset>/<train_split>.csv` and `label` its class.
`D1_train` feeds `D1_original`, `D4b_D1`, `D4r_D1`, `D6_fairprompt` and
`D5_decontam` (the same rows under anonymised column names), `D2_train` feeds
`D2_fair_causal`, `D4b_D2` and `D4r_D2`, and `D3_train` feeds `D3_resampled`.
The result files do not store these rows. The table is reconstructed from the
splits with `select_fewshot_examples` (`src/hf_classifier.py`), and the hash
of the reconstructed rows equals the `demos_sha256` archived in
`_generation_stats.csv` for every pass of `D1_original`, `D2_fair_causal`,
`D3_resampled`, `D5_decontam` and `D6_fairprompt`. For `D4b_D1`, `D4b_D2`,
`D4r_D1` and `D4r_D2` that field is the hash of an empty input, so the rows
listed for them rest on the reconstruction alone.
