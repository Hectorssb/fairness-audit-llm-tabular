# Validation responses and batch-size check

The zero-shot passes in `results/` store the predicted labels and not the text
the model generated. The files here are a validation set of responses collected
with the prompts and inference code of this repository, with every response
kept as text. They show how often a response carries no readable label and how
far the validation predictions agree with the archived ones.

## zero_shot_responses/

One file per zero-shot pass (`ZS_D1` and `ZS_D5`, eight models, three datasets
and two test sets: 96 passes of 500 instances), named after the pass in
`results/` with the suffix `_responses.csv`:

- `instance_idx`: position of the instance in the test set.
- `response`: text the model generated.
- `label`: class read from the response (the negative class when none could
  be read).
- `defaulted`: `True` when no label could be read and the negative class was
  assigned.
- `y_pred`: prediction read from the validation response.

`summary.json` gives, per pass, the number of instances, the validation
responses without a readable label (`unread`), the count of such responses
archived with the pass in `results/` (`stored_count`) and the instances whose
validation prediction equals the archived one (`same_as_stored`). Seven of the
eight models agree with the archived predictions on every instance. GPT-OSS-20B
agrees on every instance in 2 of its 12 passes and on 85.2% to 99.0% of the
instances in the other 10. For `compas_ZS_D5_LLM_ZeroShot_microsoft-phi-4` the
archived count is 4 and the validation responses give 344: the archived count
was written by an earlier version of the parser, and both versions read the
same predicted labels from these responses.

## phi4_second_request/

The four passes of Phi-4 under `ZS_D5` on Adult Income and COMPAS, where the
model declines to answer for part of the instances. Every response without a
label was followed by a second request for the label alone. The files hold
`instance_idx`, `response`, `y_pred` and `defaulted` as above,
`second_response`, `y_pred_second` and `second_defaulted` for that request, and
`y_true`, `sex` and `race` of the instance. `summary.json`
counts, per pass, the responses without a label after the first request
(`defaulted`) and after the second (`second_still_unread`).

## gptoss_validation/

GPT-OSS-20B is the one model whose validation predictions differ from the
archived ones.

- `batch_size.json`: predictions of
  `adult_ZS_D5_LLM_ZeroShot_openai-gpt-oss-20b` collected twice at the
  reference batch size (`default_1`, `default_2`) and with batch sizes 1, 4
  and 32, next to the archived predictions (`stored`) and those of
  `zero_shot_responses/` (`audit`).
- `summary.json`: positive predictions of every entry of `batch_size.json`,
  number of equal predictions for every pair of entries, and package versions.
- `draws.json`: the `D1_original` passes on German Credit under the three
  demonstration seeds and on both test sets, collected in one software
  environment, with their positive predictions (`positives`), those of the
  archived pass (`stored_positives`), the instances whose prediction equals
  the archived one (`same_as_stored`) and the predictions (`y_pred`).
